# PitMau · Documentação

## 1. Visão geral
PitMau é uma ferramenta web para tratar ficheiros do dia a dia diretamente no browser. Nada é enviado para servidores: o processamento é local, o que garante privacidade.

A versão 0.1 cobre imagens e criação de PDF. A arquitetura permite acrescentar novas ferramentas como módulos independentes (secções 8 e 9).

## 2. Funcionalidades (v0.1)
| Ferramenta | O que faz |
|---|---|
| Carregar | Escolher, arrastar ou colar (Ctrl+V) imagens |
| Recortar | Arrastar sobre a imagem e aplicar |
| Redimensionar | Largura e altura com bloqueio de proporção |
| Rodar e espelhar | 90° para ambos os lados, horizontal e vertical |
| Filtros | Brilho, contraste, saturação, desfoque, preto e branco, sépia |
| Remover fundo | Remoção por cor com tolerância e suavidade das bordas; cor por conta-gotas |
| Converter e comprimir | Exportar para PNG, JPG ou WebP com controlo de qualidade |
| Histórico | Até 15 passos de "Desfazer" (também Ctrl+Z) |
| Imagens para PDF | Várias imagens em ordem personalizável, uma por página |

## 3. Estrutura do projeto
```
pitmau/
├── index.html          Estrutura e semântica da página
├── css/style.css       Estilos, tema escuro, layout responsivo
├── js/app.js           Lógica da aplicação
└── docs/DOCUMENTACAO.md
```

## 4. Como executar
1. Extrai o zip.
2. Abre `index.html` no browser, ou serve a pasta com `python3 -m http.server 8000` e acede a `http://localhost:8000`.

Não há dependências nem passo de build.

## 5. Arquitetura (`js/app.js`)
- **Estado:** `work` é o canvas com os píxeis confirmados; `hist` guarda cópias para o "Desfazer".
- **Fluxo:** os filtros são pré-visualizados com `ctx.filter` em `render()`. Cada operação cria um novo canvas a partir de `snap()` (imagem já com filtros) e chama `commit()`.
- **Recorte:** eventos de ponteiro (rato e toque) convertem coordenadas do ecrã para píxeis da imagem.
- **Remover fundo:** distância de cor em RGB. Abaixo da tolerância o pixel fica transparente; na faixa de suavidade a opacidade cresce gradualmente.
- **PDF:** `buildPdf()` escreve um PDF 1.4 com imagens JPEG, sem bibliotecas externas.
- **Exportação:** `canvas.toBlob()` e download por link temporário. O JPG recebe fundo branco no lugar da transparência.

## 6. Desempenho e acessibilidade
- Sem frameworks nem dependências, carregamento mínimo.
- Pré-visualização escalada por CSS.
- Navegação por teclado, foco visível, avisos com `aria-live`, `prefers-reduced-motion` respeitado.
- Duas colunas no computador e coluna única abaixo de 800px.

## 7. Limitações conhecidas
- A remoção de fundo é por cor: funciona bem em fundos lisos, não em fotografias complexas.
- Safari antigo não suporta `ctx.filter`: os filtros não aparecem na pré-visualização.
- Imagens acima de ~64 megapíxeis são recusadas no redimensionamento.
- AVIF e WebP dependem do suporte do browser.
- O PDF usa JPEG a 92% e fundo branco onde há transparência.

## 8. Roteiro
1. **PDF:** juntar, dividir, rodar e extrair páginas (`pdf-lib`); PDF para imagens (`pdf.js`).
2. **Remoção de fundo com IA:** `@imgly/background-removal` carregado sob demanda.
3. **Documentos:** conversão entre TXT, MD, HTML, CSV e JSON; leitura de DOCX com `mammoth`.
4. **Áudio e vídeo:** converter, cortar e extrair áudio com `ffmpeg.wasm`.
5. **Lote e ZIP:** processar vários ficheiros e descarregar num zip (`JSZip`).
6. **PWA:** `manifest.json` e service worker para uso offline.
7. **Modularização:** dividir `app.js` em módulos ES (`tools/image.js`, `tools/pdf.js`) com um registo de ferramentas.

## 9. Como acrescentar uma ferramenta
1. Em `index.html`, adiciona um botão `.tab` com `data-t="id"` e uma `<section id="id" class="view" hidden>`.
2. Escreve a lógica em `app.js` (ou num novo módulo) e liga-a aos controlos.
3. Reutiliza `.btn`, `.panel`, `.card` e as variáveis CSS de `:root`.

## 10. Privacidade
Os ficheiros nunca saem do dispositivo. Não há cookies, analytics nem pedidos de rede.
